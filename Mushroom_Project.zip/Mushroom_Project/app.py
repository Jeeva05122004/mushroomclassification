import streamlit as st
import pickle
from sklearn.preprocessing import LabelEncoder, StandardScaler
import numpy as np

def load_model():
    try:
        with open(r"C:\CODE\Projects\Mushroom_Project\models\svm_model.pkl", 'rb') as file:
            model = pickle.load(file)
        with open(r"C:\CODE\Projects\Mushroom_Project\models\label_encoders.pkl", 'rb') as file:
            label_encoders = pickle.load(file)
        with open(r"C:\CODE\Projects\Mushroom_Project\models\scaler.pkl", 'rb') as file:
            scaler = pickle.load(file)
            
        # Get the actual classes from the label encoders
        feature_options = {}
        for feature, le in label_encoders.items():
            feature_options[feature] = le.classes_.tolist()
            
        return model, label_encoders, scaler, feature_options
    except Exception as e:
        st.error(f"Error loading models: {str(e)}")
        return None, None, None, None

def transform_input(input_dict, label_encoders, scaler):
    try:
        transformed_values = []
        for feature, value in input_dict.items():
            if feature in label_encoders:
                le = label_encoders[feature]
                if value not in le.classes_:
                    raise ValueError(f"Unknown value '{value}' for feature '{feature}'")
                transformed_value = le.transform([value])[0]
                transformed_values.append(transformed_value)
            else:
                raise ValueError(f"No encoder found for feature '{feature}'")
        
        input_array = np.array(transformed_values).reshape(1, -1)
        input_scaled = scaler.transform(input_array)
        return input_scaled
    
    except Exception as e:
        st.error(f"Error in transformation: {str(e)}")
        return None

def main():
    st.title("🍄 Mushroom Edibility Classifier")
    st.write("Enter mushroom characteristics to predict if it's edible or poisonous")
    
    # Load model and encoders
    model, label_encoders, scaler, feature_options = load_model()
    if model is None:
        return
    
    # Create columns for better layout
    col1, col2 = st.columns(2)
    
    # Create input dictionary to store user inputs
    input_dict = {}
    
    # Split features between columns
    features = list(feature_options.keys())
    mid_point = len(features) // 2
    
    # Create input fields in two columns
    with col1:
        st.subheader("Physical Characteristics")
        for feature in features[:mid_point]:
            input_dict[feature] = st.selectbox(
                f"{feature.replace('-', ' ').title()}",
                options=feature_options[feature]
            )
    
    with col2:
        st.subheader("Additional Characteristics")
        for feature in features[mid_point:]:
            input_dict[feature] = st.selectbox(
                f"{feature.replace('-', ' ').title()}",
                options=feature_options[feature]
            )
    
    # Create a predict button
    if st.button("Predict Edibility", type="primary"):
        input_scaled = transform_input(input_dict, label_encoders, scaler)
        
        if input_scaled is not None:
            try:
                prediction = model.predict(input_scaled)[0]
                
                st.markdown("---")
                if prediction == 0:
                    st.success("🍄 This mushroom is predicted to be EDIBLE")
                else:
                    st.error("☠️ This mushroom is predicted to be POISONOUS")
                    st.warning("⚠️ Never eat wild mushrooms without expert verification!")
                
                st.info("Note: This is a prediction model and should not be used as the sole basis for determining if a mushroom is safe to eat. Always consult with mycology experts.")
            
            except Exception as e:
                st.error(f"Error making prediction: {str(e)}")

if __name__ == "__main__":
    main()